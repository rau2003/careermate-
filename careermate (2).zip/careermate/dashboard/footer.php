<footer>
    <div class="footer-links">
        <a href="about.html">About</a> | <a href="contact.html">Contact</a>
    </div>
    <div class="social-media">
        <a href="#"><img src="images/instagram-icon.png" alt="Instagram"></a>
        <a href="#"><img src="images/facebook-icon.png" alt="Facebook"></a>
        <a href="#"><img src="images/youtube-icon.png" alt="YouTube"></a>
    </div>
    <div class="address">
        <p>221005 Seer-gate, Uttar-Pradesh, Varanasi, India</p>
    </div>
    <p>&copy; CareerMate | All rights reserved</p>
</footer>
