<div class="header-container-unique">
    <div class="header-content-unique">
        <img src="images/logo.png" alt="Logo" class="header-logo-unique">
        <h1 class="header-title-unique">Dashboard</h1>
        <button class="header-logout-btn-unique" onclick="logout()">Logout</button>
    </div>
</div>
